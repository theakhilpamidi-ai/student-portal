import path from 'node:path'
import { fileURLToPath } from 'node:url'
import express from 'express'
import cookieParser from 'cookie-parser'
import mongoose from 'mongoose'
import authRoutes from './routes/auth.js'

const { MONGODB_URI, JWT_SECRET, PORT = 5000, NODE_ENV } = process.env
if (!MONGODB_URI || !JWT_SECRET) {
  console.error('Missing MONGODB_URI or JWT_SECRET. Copy .env.example to .env and fill it in.')
  process.exit(1)
}

const app = express()
app.use(express.json())
app.use(cookieParser())
app.use('/api/auth', authRoutes)

// In production, serve the built React app from the same server.
if (NODE_ENV === 'production') {
  const dist = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'dist')
  app.use(express.static(dist))
  app.get('*', (_req, res) => res.sendFile(path.join(dist, 'index.html')))
}

mongoose
  .connect(MONGODB_URI)
  .then(() => app.listen(PORT, () => console.log(`API ready on http://localhost:${PORT}`)))
  .catch((err) => {
    console.error('MongoDB connection failed:', err.message)
    process.exit(1)
  })
