import jwt from 'jsonwebtoken'

export default function requireAuth(req, res, next) {
  const token = req.cookies?.token
  if (!token) return res.status(401).json({ error: 'Sign in to continue.' })
  try {
    req.userId = jwt.verify(token, process.env.JWT_SECRET).sub
    next()
  } catch {
    res.clearCookie('token')
    res.status(401).json({ error: 'Your session expired. Sign in again.' })
  }
}
