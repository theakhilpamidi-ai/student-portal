import mongoose from 'mongoose'

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true, maxlength: 80 },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    studentId: { type: String, trim: true },
    passwordHash: { type: String, required: true },
  },
  { timestamps: true }
)

// Never send the password hash to the browser.
userSchema.methods.toPublic = function () {
  return { id: this._id, name: this.name, email: this.email, studentId: this.studentId }
}

export default mongoose.model('User', userSchema)
