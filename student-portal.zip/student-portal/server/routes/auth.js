import { Router } from 'express'
import bcrypt from 'bcryptjs'
import jwt from 'jsonwebtoken'
import User from '../models/User.js'
import requireAuth from '../middleware/requireAuth.js'

const router = Router()
const WEEK = 7 * 24 * 60 * 60 * 1000

function setSession(res, user) {
  const token = jwt.sign({ sub: user.id }, process.env.JWT_SECRET, { expiresIn: '7d' })
  res.cookie('token', token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    maxAge: WEEK,
  })
}

router.post('/register', async (req, res) => {
  const { name, email, studentId, password } = req.body ?? {}
  if (!name || !email || !password) {
    return res.status(400).json({ error: 'Enter your name, email, and password.' })
  }
  if (password.length < 8) {
    return res.status(400).json({ error: 'Use a password with at least 8 characters.' })
  }
  try {
    if (await User.findOne({ email: email.toLowerCase() })) {
      return res.status(409).json({ error: 'An account with this email already exists. Sign in instead.' })
    }
    const passwordHash = await bcrypt.hash(password, 12)
    const user = await User.create({ name, email, studentId, passwordHash })
    setSession(res, user)
    res.status(201).json({ user: user.toPublic() })
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: 'Could not create your account. Try again.' })
  }
})

router.post('/login', async (req, res) => {
  const { email, password } = req.body ?? {}
  if (!email || !password) {
    return res.status(400).json({ error: 'Enter your email and password.' })
  }
  try {
    const user = await User.findOne({ email: email.toLowerCase() })
    const ok = user && (await bcrypt.compare(password, user.passwordHash))
    if (!ok) return res.status(401).json({ error: 'Email or password is incorrect.' })
    setSession(res, user)
    res.json({ user: user.toPublic() })
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: 'Could not sign you in. Try again.' })
  }
})

router.get('/me', requireAuth, async (req, res) => {
  const user = await User.findById(req.userId)
  if (!user) return res.status(401).json({ error: 'Account not found.' })
  res.json({ user: user.toPublic() })
})

router.post('/logout', (_req, res) => {
  res.clearCookie('token')
  res.json({ ok: true })
})

export default router
